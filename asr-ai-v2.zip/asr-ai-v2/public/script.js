const messagesEl = document.getElementById("messages");
const typingEl   = document.getElementById("typing");
const form       = document.getElementById("chat-form");
const input      = document.getElementById("user-input");
let history = [];
function appendMessage(text, who = "ai") {
  const div = document.createElement("div");
  div.className = `msg ${who}`;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function setTyping(v) {
  typingEl.classList.toggle("hidden", !v);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  appendMessage(text, "user");
  history.push({ role: "user", content: text });
  input.value = "";
  input.focus();
  setTyping(true);
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history })
    });
    if (!res.ok) {
      const err = await res.text();
      console.error(err);
      appendMessage("Oops, the server returned an error.", "ai");
      setTyping(false);
      return;
    }
    const data = await res.json();
    const answer = data.answer || "I couldn't think of anything to say.";
    appendMessage(answer, "ai");
    history.push({ role: "assistant", content: answer });
  } catch (err) {
    console.error(err);
    appendMessage("Network error. Is the server running?", "ai");
  } finally {
    setTyping(false);
  }
});
appendMessage("Hi! I’m Asr.ai 🤖✨\nAsk me anything for your school project.", "ai");
const canvas = document.getElementById("bg-particles");
const ctx = canvas.getContext("2d");
let w,h,particles;
function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; particles = Array.from({length: Math.min(120, Math.floor((w*h)/25000))}, () => ({ x: Math.random()*w, y: Math.random()*h, vx: (Math.random()-0.5)*0.25, vy: (Math.random()-0.5)*0.25, r: Math.random()*1.6 + 0.4 })); }
window.addEventListener("resize", resize);
resize();
function draw(){ ctx.clearRect(0,0,w,h); ctx.globalAlpha = 0.8; for(const p of particles){ p.x += p.vx; p.y += p.vy; if(p.x<0||p.x>w) p.vx*=-1; if(p.y<0||p.y>h) p.vy*=-1; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fillStyle = "rgba(180, 160, 255, 0.5)"; ctx.fill(); } requestAnimationFrame(draw); }
draw();
